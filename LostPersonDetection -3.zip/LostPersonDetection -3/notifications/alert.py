def send_mock_notification(name, phone, location, message):
    print(f"[Mock Notification] To: {name} ({phone}) at {location}: {message}")
