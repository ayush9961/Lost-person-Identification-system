import sys
import os
import cv2
import pandas as pd
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QLineEdit, QFileDialog, QFormLayout, QTextEdit, QTableWidget,
    QTableWidgetItem
)
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer

from detection.detector import detect_person, load_known_faces, record_video_clip
from database.db import save_lost_person, load_lost_person
from notifications.alert import send_mock_notification

DETECTED_LOG = "detection_logs.xlsx"
SENT_ALERTS = []

class LostPersonApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🔍 Lost Person Detection System")
        self.setGeometry(100, 100, 1200, 700)

        self.tabs = QTabWidget()
        self.monitor_tab = QWidget()
        self.register_tab = QWidget()
        self.logs_tab = QWidget()

        self.tabs.addTab(self.monitor_tab, "Live CCTV Feed")
        self.tabs.addTab(self.register_tab, "Register Lost Person")
        self.tabs.addTab(self.logs_tab, "Detection Logs")

        self.setCentralWidget(self.tabs)

        self.detected_ids = set()
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

        self.setup_monitor_tab()
        self.setup_register_tab()
        self.setup_logs_tab()

        load_known_faces()

    def setup_monitor_tab(self):
        layout = QVBoxLayout()
        self.video_label = QLabel("Webcam Feed")
        self.video_label.setFixedSize(800, 600)
        layout.addWidget(self.video_label)

        self.status_label = QLabel("Status: Waiting for detection...")
        layout.addWidget(self.status_label)

        self.monitor_tab.setLayout(layout)

    def setup_register_tab(self):
        layout = QFormLayout()
        self.person_id = QLineEdit()
        self.contact_info = QLineEdit()
        self.location_info = QLineEdit()
        self.reporter_name = QLineEdit()
        self.reporter_contact = QLineEdit()
        self.photo_path = QLineEdit()
        self.photo_path.setReadOnly(True)

        browse_btn = QPushButton("Browse Image")
        browse_btn.clicked.connect(self.browse_image)
        save_btn = QPushButton("Save Entry")
        save_btn.clicked.connect(self.save_person)

        layout.addRow("Person ID:", self.person_id)
        layout.addRow("Contact Info:", self.contact_info)
        layout.addRow("Last Seen Location:", self.location_info)
        layout.addRow("Reporter Name:", self.reporter_name)
        layout.addRow("Reporter Contact:", self.reporter_contact)
        layout.addRow("Photo:", self.photo_path)
        layout.addRow(browse_btn)
        layout.addRow(save_btn)

        self.save_status = QLabel("")
        layout.addRow(self.save_status)
        self.register_tab.setLayout(layout)

    def setup_logs_tab(self):
        layout = QVBoxLayout()
        self.sms_log = QTextEdit()
        self.sms_log.setReadOnly(True)
        layout.addWidget(QLabel("📱 Sent Mock Notifications:"))
        layout.addWidget(self.sms_log)

        self.table = QTableWidget()
        layout.addWidget(QLabel("📋 Detection Excel Log:"))
        layout.addWidget(self.table)

        refresh_btn = QPushButton("🔄 Refresh Logs")
        refresh_btn.clicked.connect(self.load_excel_log)
        layout.addWidget(refresh_btn)

        self.logs_tab.setLayout(layout)

    def browse_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Image", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            self.photo_path.setText(file_path)

    def save_person(self):
        pid = self.person_id.text()
        contact = self.contact_info.text()
        location = self.location_info.text()
        reporter = self.reporter_name.text()
        reporter_contact = self.reporter_contact.text()
        img_path = self.photo_path.text()

        if not all([pid, contact, location, reporter, reporter_contact, img_path]):
            self.save_status.setText("⚠️ Please fill all fields.")
            return

        save_dir = os.path.join("lost_persons", pid)
        os.makedirs(save_dir, exist_ok=True)
        new_img_path = os.path.join(save_dir, os.path.basename(img_path))
        img = cv2.imread(img_path)
        if img is None:
            self.save_status.setText("❌ Error loading image.")
            return
        cv2.imwrite(new_img_path, img)

        person = {
            "id": pid,
            "contact": contact,
            "location": location,
            "image_path": new_img_path,
            "reporter": reporter,
            "reporter_contact": reporter_contact
        }

        save_lost_person(person)
        load_known_faces()
        self.save_status.setText("✅ Lost person registered successfully.")
        self.person_id.clear()
        self.contact_info.clear()
        self.location_info.clear()
        self.reporter_name.clear()
        self.reporter_contact.clear()
        self.photo_path.clear()

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        detected, person_id = detect_person(frame)

        if detected:
            self.status_label.setText(f"✅ Match Found: Person ID {person_id}")

            if person_id not in self.detected_ids:
                self.detected_ids.add(person_id)

                time_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                video_path = record_video_clip(person_id, self.cap)

                # Get reporter info
                person_data = load_lost_person(person_id)
                reporter = person_data.get("reporter", "Unknown") if person_data else "Unknown"
                reporter_contact = person_data.get("reporter_contact", "Unknown") if person_data else "Unknown"

                mock_message = f"[Mock SMS] Person ID: {person_id} found at {time_now}"
                send_mock_notification(person_id, reporter, reporter_contact, "Detected Location")
                SENT_ALERTS.append(mock_message)
                self.sms_log.append(mock_message)

                if os.path.exists(DETECTED_LOG):
                    df = pd.read_excel(DETECTED_LOG)
                else:
                    df = pd.DataFrame(columns=["Person ID", "Time Detected", "Location", "Video", "Reporter", "Reporter Contact"])

                new_entry = pd.DataFrame([{
                    "Person ID": person_id,
                    "Time Detected": time_now,
                    "Location": "Detected Location",
                    "Video": video_path,
                    "Reporter": reporter,
                    "Reporter Contact": reporter_contact
                }])
                df = pd.concat([df, new_entry], ignore_index=True)
                df.to_excel(DETECTED_LOG, index=False)

                self.load_excel_log()
        else:
            self.status_label.setText("No match found.")

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        img = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(img))

    def load_excel_log(self):
        if os.path.exists(DETECTED_LOG):
            df = pd.read_excel(DETECTED_LOG)
            self.table.setRowCount(len(df))
            self.table.setColumnCount(len(df.columns))
            self.table.setHorizontalHeaderLabels(df.columns)

            for i in range(len(df)):
                for j in range(len(df.columns)):
                    self.table.setItem(i, j, QTableWidgetItem(str(df.iat[i, j])))

def main():
    app = QApplication(sys.argv)
    win = LostPersonApp()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
