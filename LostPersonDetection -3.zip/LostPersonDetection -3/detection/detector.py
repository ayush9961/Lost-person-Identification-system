import face_recognition
import cv2
import os
import time
from datetime import datetime
import pandas as pd

known_encodings = []
known_ids = []
VIDEO_DIR = "captured_videos"
LOG_FILE = "detection_logs.xlsx"

os.makedirs(VIDEO_DIR, exist_ok=True)

def load_known_faces():
    global known_encodings, known_ids
    known_encodings = []
    known_ids = []
    base_dir = "lost_persons"

    if not os.path.exists(base_dir):
        os.makedirs(base_dir)

    for person_id in os.listdir(base_dir):
        person_path = os.path.join(base_dir, person_id)
        if os.path.isdir(person_path):
            for img_file in os.listdir(person_path):
                img_path = os.path.join(person_path, img_file)
                image = face_recognition.load_image_file(img_path)
                locations = face_recognition.face_locations(image)
                encodings = face_recognition.face_encodings(image, locations)
                if encodings:
                    known_encodings.append(encodings[0])
                    known_ids.append(person_id)

def detect_person(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    locations = face_recognition.face_locations(rgb)
    encodings = face_recognition.face_encodings(rgb, locations)

    for encoding in encodings:
        matches = face_recognition.compare_faces(known_encodings, encoding)
        if True in matches:
            index = matches.index(True)
            return True, known_ids[index]
    return False, None

def record_video_clip(person_id, cap, duration=5):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    video_path = os.path.join(VIDEO_DIR, f"{person_id}_{timestamp}.avi")
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(video_path, fourcc, 20.0, (640, 480))

    start = time.time()
    while time.time() - start < duration:
        ret, frame = cap.read()
        if not ret:
            break
        out.write(frame)
    out.release()
    return video_path

def log_detection(person_id, reporter_name, reporter_phone):
    log_data = {
        "Lost Person ID": person_id,
        "Reporter Name": reporter_name,
        "Reporter Phone": reporter_phone,
        "Detection Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Location": "CCTV Camera 1"
    }

    df = pd.DataFrame([log_data])
    if not os.path.exists(LOG_FILE):
        df.to_excel(LOG_FILE, index=False)
    else:
        existing_df = pd.read_excel(LOG_FILE)
        new_df = pd.concat([existing_df, df], ignore_index=True)
        new_df.to_excel(LOG_FILE, index=False)
