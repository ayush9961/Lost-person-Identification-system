import os
import pickle

DB_FILE = "database/lost_persons.db"

def init_db():
    if not os.path.exists("database"):
        os.makedirs("database")
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "wb") as f:
            pickle.dump([], f)

def save_lost_person(person):
    init_db()
    with open(DB_FILE, "rb") as f:
        data = pickle.load(f)
    
    # Check if person ID already exists and update it
    for i, existing in enumerate(data):
        if existing["id"] == person["id"]:
            data[i] = person
            break
    else:
        data.append(person)

    with open(DB_FILE, "wb") as f:
        pickle.dump(data, f)

def load_lost_persons():
    init_db()
    with open(DB_FILE, "rb") as f:
        return pickle.load(f)

def load_lost_person(person_id):
    persons = load_lost_persons()
    for person in persons:
        if person["id"] == person_id:
            return person
    return None
